//Name: Bethany Spatafora
//File: mystring.cpp

#include <iostream>
#include "mystring.h"

int str_len(char x[])
{
    int len = 0;
    while(x[len] != '\0') ++len;

    return len;
}

void str_cat(char x[], char y[])
{
    int xlen = str_len(x);
    int ylen = str_len(y);

    for(int i = 0; i <= ylen; ++i) x[xlen + i] = y[i];

    return;
}

int str_cmp(char x[], char y[])
{
    int xlen = str_len(x);
    int ylen = str_len(y);
    if(xlen == ylen)
    {
        for(int i = 0; i < xlen; ++i)
        {
            if(x[i] != y[i]) return 1;
        }
        return 0;
    }
    return 1;
}

void str_cpy(char x[], char y[])
{
    int ylen = str_len(y);
    for(int i = 0; i <= ylen; ++i)
    {
        x[i] = y[i];
    }

    return;
}

int str_chr(char x[], char c)
{
    int xlen = str_len(x);

    for(int i = 0; i < xlen; ++i)
    {
        if(x[i] == c) return i;
    }

    return -1;
}

int str_str(char x[], char y[])
{
    int xlen = str_len(x);
    int ylen = str_len(y);

    for(int i = 0; i < xlen - ylen; ++i)
    {
        if(x[i] == y[0])
        {
            bool yes = (ylen > 1? 0:1);
            int ti = i + 1;
            for(int j = 1; j < ylen; ++j)
            {
                if(x[ti] != y[j]) break;
                if(j == ylen - 1) yes = 1;
                ++ti;
            }
            if(yes) return i;
        }
    }

    return -1;
}

void str_lower(char x[], char y[])
{
    int ylen = str_len(y);

    for(int i = 0; i < ylen; ++i)
    {
        if(y[i] >= 'A' && y[i] <= 'Z') y[i] = y[i] - 'A' + 'a';
    }

    str_cpy(x, y);

    return;
}

bool str_tok(char x[], char y[], char delimiters[])
{
    int ylen = str_len(y);
    int dlen = str_len(delimiters);
    int split_i = -1;
    for(int i = 0; i < dlen && split_i == -1; ++i)
    {
        split_i = str_chr(y, delimiters[i]);
    }
    
    if(split_i != -1)
    {
        for(int i = 0; i < split_i; ++i)
            x[i] = y[i];
        x[split_i] = '\0';
        for(int i = 0; i < ylen - split_i + 1; ++i)
        {
            y[i] = y[split_i + i + 1];
        }
        y[ylen - split_i] = '\0';
    }
    else
    {
        str_cpy(x, y);
        y[0] = '\0';
    }
    
    return (split_i > -1 || x[0] != '\0');
}
    
    

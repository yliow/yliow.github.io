//Name: Bethany Spatafora
//File: mystring.h

#ifndef MYSTRING_H
#define MYSTRING_H

int str_len(char []);
void str_cat(char [], char []);
int str_cmp(char x[], char y[]);
void str_cpy(char x[], char y[]);
int str_chr(char x[], char c);
int str_str(char x[], char y[]);
void str_lower(char x[], char y[]);
bool str_tok(char x[], char y[], char delimiters[]);

#endif
